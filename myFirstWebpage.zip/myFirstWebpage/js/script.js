function changeImage(){

document.getElementById("animalCrossing1").src = "images/giphy2.gif";	
}