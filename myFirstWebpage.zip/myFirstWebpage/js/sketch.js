
function setup() {
  createCanvas(400, 400);
  background(250,0,0);
  pop();
}

function draw() {
  
  ellipse(mouseX, mouseY, 100,100);
}

